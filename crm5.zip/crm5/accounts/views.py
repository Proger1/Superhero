from django.shortcuts import render,redirect
from django.shortcuts import HttpResponse
# Create your views here.
from .models import *
from .forms import SuperheroForm


def home(request):
    superheroes = Superhero.objects.all()
      
    context = {'superheroes' :superheroes}


    return render(request, 'accounts/dashboard.html', context)


def superheroes(request):
	superheroes = Superhero.objects.all()

	return render(request, 'accounts/superheroes.html', {'superheroes' :superheroes})


def createSuperhero(request):
    form = SuperheroForm()
    if request.method == 'POST':
    	# print('Printing POST:',request.POST)
    	form = SuperheroForm(request.POST,request.FILES)
    	if form.is_valid():
    		form.save()
    		return redirect('/') #Возврат на главную

    context = {'form':form}

    return render(request, 'accounts/superhero_form.html',context)



def editSuperhero(request, pk):

    superhero=Superhero.objects.get(id=pk)
    form=SuperheroForm(instance=superhero)

    if request.method == 'POST':
    	# print('Printing POST:',request.POST)
    	form = SuperheroForm(request.POST, request.FILES, instance=superhero)
    	if form.is_valid():
    		form.save()
    		return redirect('/') #Возврат на главную
    context = {'form':form}
    return render(request, 'accounts/superhero_form.html',context) 



def deleteSuperhero(request,pk):
    superhero=Superhero.objects.get(id=pk)
    if request.method == "POST":
        superhero.delete() 
        return redirect('/') #Возврат на главную 
    context={'item' :superhero}
    return render(request, 'accounts/delete.html',context)
